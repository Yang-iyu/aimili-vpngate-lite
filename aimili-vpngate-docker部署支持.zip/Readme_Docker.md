﻿# AimiliVPN Docker 部署指南

本文档说明如何使用 Docker 部署 AimiliVPN。Docker 部署文件不会修改现有 Python 源码，运行数据保存在宿主机的 `vpngate_data` 目录中。

## 1. 部署文件

项目根目录新增以下文件：

- `Dockerfile`：基于 Python 3.12 和 Debian Bookworm 构建运行镜像。
- `compose.yaml`：配置 TUN 设备、网络权限、端口映射、数据持久化及健康检查。
- `Readme_Docker.md`：本部署指南。

## 2. 环境要求

### Linux 服务器

- 已安装 Docker Engine 和 Docker Compose。
- 内核支持 TUN/TAP。
- `/dev/net/tun` 存在。
- 建议使用 root 或具有 Docker 权限的账号执行命令。

检查 TUN：

```bash
ls -l /dev/net/tun
```

如果设备不存在，可尝试：

```bash
sudo modprobe tun
```

### Windows 本地测试

- 安装并启动 Docker Desktop。
- 使用 Linux containers 模式。
- 启用 WSL 2 后端。
- 等待 Docker Desktop 显示引擎已正常运行。

检查环境：

```powershell
docker version
docker compose version
```

如果当前 Docker CLI 没有注册 `docker compose` 子命令，可直接调用 Docker Desktop 自带插件：

```powershell
& 'C:\Program Files\Docker\Docker\resources\cli-plugins\docker-compose.exe' version
```

## 3. 配置说明

Compose 配置会为容器提供：

- `/dev/net/tun` TUN 设备。
- `NET_ADMIN` 和 `NET_RAW` 能力。
- `privileged: true`，用于 OpenVPN、策略路由和 iptables 操作。
- `net.ipv4.ip_forward=1`。
- `net.ipv4.conf.all.rp_filter=2`。
- 宿主机 `./vpngate_data` 到容器 `/app/vpngate_data` 的持久化映射。

默认端口：

- `8787`：Web 管理界面。
- `7928`：主 HTTP/SOCKS5 代理。
- `7925`、`7926`、`7927`、`7929`：额外代理端口。

代理端口默认只发布到宿主机 `127.0.0.1`，避免未经授权地暴露到公网。Web 管理端口 `8787` 会发布到所有宿主机接口，生产环境应使用防火墙、安全组或反向代理限制访问。

## 4. 构建并启动

在项目根目录执行：

```bash
docker compose up -d --build
```

查看状态：

```bash
docker compose ps
```

查看实时日志：

```bash
docker compose logs -f aimilivpn
```

首次启动后，程序会拉取 VPNGate 节点并执行连通性测试，这个过程可能需要一些时间。

## 5. 获取管理地址和账号

首次启动时，程序会在 `vpngate_data/ui_auth.json` 中生成管理路径、用户名和密码。

Linux：

```bash
cat vpngate_data/ui_auth.json
```

Windows PowerShell：

```powershell
Get-Content .\vpngate_data\ui_auth.json
```

管理地址格式：

```text
http://127.0.0.1:8787/<secret_path>/
```

直接访问 `http://127.0.0.1:8787/` 返回 HTTP 404 是预期的安全行为，必须在 URL 中包含 `secret_path`。

请妥善保存 `ui_auth.json`，不要将其中的密码和安全路径提交到代码仓库或公开分享。

## 6. 本地验证

### 检查容器健康状态

```bash
docker inspect --format '{{json .State.Health}}' aimilivpn
```

状态应显示为 `healthy`。

### 检查 TUN 与运行依赖

```bash
docker exec aimilivpn sh -lc 'id; test -c /dev/net/tun && echo TUN_OK; command -v openvpn; command -v ip; command -v iptables'
```

预期结果包括：

- 容器进程以 root 身份运行。
- 输出 `TUN_OK`。
- 能找到 `openvpn`、`ip` 和 `iptables`。

### 检查监听端口

```bash
docker exec aimilivpn ss -lntp
```

初始状态下至少应看到：

- `0.0.0.0:8787`
- `0.0.0.0:7928`

其他代理端口是否监听取决于相应出口槽位是否已启用。

### 验证管理登录页

将下面地址中的安全路径替换成 `ui_auth.json` 内的 `secret_path`：

```bash
curl -I http://127.0.0.1:8787/<secret_path>/
```

页面应返回 HTTP 200。

### 验证主代理端口

主代理支持 HTTP 和 SOCKS5。只有成功连接 VPN 节点并生成 `tun0` 后，才能验证真实代理出口。

SOCKS5：

```bash
curl --socks5-hostname 127.0.0.1:7928 --max-time 20 https://api.ipify.org
```

HTTP：

```bash
curl -x http://127.0.0.1:7928 --max-time 20 https://api.ipify.org
```

如果尚未建立 VPN 隧道，代理出口测试失败属于预期情况。先登录管理界面，等待节点检测完成并连接一个可用节点。

## 7. 多出口验证

在管理界面启用出口槽位后，可在容器内运行项目自带的检查脚本：

```bash
docker exec aimilivpn bash /app/scripts/selfcheck_multiexit.sh /app/vpngate_data
```

脚本会检查每个槽位的：

1. TUN 设备。
2. 独立策略路由表及规则。
3. 代理端口监听状态。
4. 真实出口 IP。

## 8. 常用维护命令

重启：

```bash
docker compose restart aimilivpn
```

停止并删除容器和网络，但保留宿主机数据：

```bash
docker compose down
```

重新构建：

```bash
docker compose build --no-cache
docker compose up -d
```

查看最后 200 行日志：

```bash
docker compose logs --tail 200 aimilivpn
```

进入容器：

```bash
docker exec -it aimilivpn bash
```

删除运行数据并完全重新初始化：

```bash
docker compose down
rm -rf vpngate_data
```

警告：最后一个命令会删除管理账号、密码、节点缓存和运行配置，请先备份。

## 9. 生产部署建议

- 不要直接将代理端口发布到公网。
- 使用主机防火墙或云安全组限制 `8787` 的来源地址。
- 如需公网访问管理界面，建议在前面配置 HTTPS 反向代理。
- 定期备份 `vpngate_data`。
- 不要通过不受信任的网络明文传输后台用户名和密码。
- 容器使用特权模式并能够修改网络配置，只应部署可信项目代码。
- 生产服务器必须确认宿主机或虚拟化平台允许 TUN、OpenVPN 和策略路由。

## 10. 故障排查

### 容器无法启动，提示找不到 `/dev/net/tun`

确认宿主机存在 TUN 设备：

```bash
ls -l /dev/net/tun
sudo modprobe tun
```

某些 OpenVZ、LXC 或受限 VPS 需要在服务商控制面板中启用 TUN/TAP。

### 管理页面根地址返回 404

这是正常的安全设计。读取 `vpngate_data/ui_auth.json`，访问带有 `secret_path` 的完整 URL。

### 容器一直处于 `health: starting`

查看日志：

```bash
docker compose logs --tail 200 aimilivpn
```

检查容器内端口：

```bash
docker exec aimilivpn ss -lntp
```

### 能打开后台但代理没有网络

- 确认已经连接可用 VPN 节点。
- 确认容器中存在 `tun0`。
- 检查 OpenVPN 日志和策略路由。
- 免费 VPNGate 节点可能握手成功但不转发流量，可在后台切换节点。

```bash
docker exec aimilivpn ip addr show tun0
docker exec aimilivpn ip rule
docker exec aimilivpn ip route show table all
docker compose logs --tail 300 aimilivpn
```

### Windows 中提示无法访问 Docker API 或命名管道

- 确认 Docker Desktop 已启动。
- 确认使用 Linux containers。
- 确认 Docker context 为 `desktop-linux`。
- 重启 Docker Desktop 后再次测试。

```powershell
docker context show
docker version
```

### `docker compose` 命令不可用

如果 Docker Desktop 已提供 Compose 插件但子命令未注册，可使用完整路径：

```powershell
$compose = 'C:\Program Files\Docker\Docker\resources\cli-plugins\docker-compose.exe'
& $compose -f compose.yaml up -d --build
& $compose -f compose.yaml ps
```

## 11. 本地测试记录

本配置已在 Windows、Docker Desktop Linux Engine 和 WSL 2 环境完成以下验证：

- Dockerfile 构建检查通过，无警告。
- Compose 配置解析通过。
- `aimilivpn:local` 镜像完整构建成功。
- 容器启动成功并进入 `healthy` 状态。
- `/dev/net/tun` 在容器内可用。
- `openvpn`、`ip`、`iptables` 和 `curl` 已安装。
- 三个 Python 源文件在容器内通过语法编译检查。
- Web 服务监听 `8787`。
- 主 HTTP/SOCKS5 代理监听 `7928`。
- 根路径返回 404，符合安全路径设计。
- 带 `secret_path` 的管理登录页返回 HTTP 200。
- 程序成功连接 VPNGate API并开始节点拉取及分层测速。

由于 VPNGate 节点的可用性和出口质量会随时间变化，真实 VPN 出口及多出口槽位测试应在节点检测完成并启用相应连接后执行。
